@extends('layouts.app')

@section('content')
<div class="container spark-screen">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
        <h1>All Commiteee Reports</h1>

		<p><a class="btn btn-info" href="{{ route('committeereport.create') }}" role="button">Add new Committee</a>
</p>  

            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                
                  <table class="table table-striped">
					<tr>
						<th>ID</th><th>Memo ID</th><th>Report Date</th><th>Submitting Ministry</th><th>Recommendation Status</th>
					</tr>
					@foreach($rows as $row)
					<tr>
						<td>{{$row->CommitteeReportID or 'DEFAULT'}}</td>
						<td>{{$row->MemoID->Memo or 'DEFAULT'}}</td>
						<td>{{$row->DocumentID->Document or 'DEFAULT'}}</td>
						<td>{{$row->MeetingID->Meeting or 'DEFAULT'}}</td>
						
						<td>{{$row->MinistryID->Ministry or 'DEFAULT'}}</td>
						<td>{{$row->RecommendationStatusID or 'DEFAULT'}}</td>
						<td><a class="btn btn-primary" href="{{ route('committeereport.show', "$row->id") }}" role="button">View</a></td>
						<td>
					Delete
						</td>
					</tr>
					@endforeach
					
				  </table>
                
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
