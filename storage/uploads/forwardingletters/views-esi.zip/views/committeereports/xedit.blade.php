@extends('layouts.app')

@section('content')
<form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>Edit Committee Report</legend>

<!-- Text input-->
<!-- <div class="form-group">
  <label class="col-md-4 control-label" for="ReferenceNo">Reference No</label>  
  <div class="col-md-4">
  <input id="ReferenceNo" name="ReferenceID" type="text" placeholder="" class="form-control input-md" required="">
    
  </div>
</div> -->

<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="MemoID"></label>
  <div class="col-md-6">
    <select id="MemoID" name="MemoID" class="form-control">
      <option value="">Select Associated Memo</option>
    </select>
  </div>
</div>

<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="DocumentDate"></label>
  <div class="col-md-4">
    <select id="DocumentDate" name="DocumentDate" class="form-control">
      <option value="">Report Date</option>
    </select>
  </div>
</div>



<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="MeetingID"></label>
  <div class="col-md-4">
    <select id="MeetingID" name="selectbasic" class="form-control">
      <option value="">Meeting ID</option>
    </select>
  </div>
</div>

<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="MinistryID"></label>
  <div class="col-md-5">
    <select id="MinistryID" name="MinistryID" class="form-control">
      <option value="">Submitting Ministry</option>
    </select>
  </div>
</div>

<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="RecommendationStatusID"></label>
  <div class="col-md-6">
    <select id="RecommendationStatusID" name="RecommendationStatusID" class="form-control">
      <option value="">Recommendation Status</option>
    </select>
  </div>
</div>

<!-- File Button --> 
<div class="form-group">
  <label class="col-md-4 control-label" for="filebutton">Upload</label>
  <div class="col-md-4">
    <input id="filename" name="filebutton" class="input-file" type="file">
  </div>
</div>

<!-- Button (Double) -->
<div class="form-group">
  <label class="col-md-4 control-label" for="button1id"></label>
  <div class="col-md-8">
    <button id="button1id" name="button1id" class="btn btn-success">Save</button>
    <button id="button2id" name="button2id" class="btn btn-danger">Cancel</button>
  </div>
</div>

</fieldset>
</form>

  @endsection