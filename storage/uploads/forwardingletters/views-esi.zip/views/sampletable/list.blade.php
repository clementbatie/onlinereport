@extends('layouts.app')

@section('content')
<div class="container spark-screen">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
        <h1>All Users</h1>

		<p><a class="btn btn-info" href="{{ route('sampletable.create') }}" role="button">Add new data</a>
</p>  

            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                
                  <table class="table table-striped">
					<tr>
						<th>ID</th><th>Name</th><th>DOB</th><th>Region</th><th></th><th></th>
					</tr>
					@foreach($rows as $row)
					<tr>
						<td>{{$row->id or 'DEFAULT'}}</td>
						<td>{{$row->AName or 'DEFAULT'}}</td>
						<td>{{$row->DateOfBirth or 'DEFAULT'}}</td>
						<td>{{$row->region->Region or 'DEFAULT'}}</td>
						<td><a class="btn btn-primary" href="{{ route('sampletable.show', "$row->id") }}" role="button">View</a></td>
						<td>
					Delete
						</td>
					</tr>
					@endforeach
					
				  </table>
                
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
