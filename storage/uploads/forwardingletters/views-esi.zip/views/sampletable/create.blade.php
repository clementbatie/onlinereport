@extends('layouts.app')

@section('content')
<div class="container spark-screen">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">

 		@include('errors.messages')

                <form class="form-horizontal" action="{{ URL::route('sampletable.store') }}" method="POST" class="form-horizontal">
           				 {{ csrf_field() }}
					<fieldset>
					
					<!-- Form Name -->
					<legend>Form Name</legend>
					
					<!-- Text input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="aname">Enter your name</label>  
					  <div class="col-md-4">
					  <input id="aname" name="aname" value="{{ old("aname") }}" type="text" placeholder="your name" class="form-control input-md" required="">
					  <span class="help-block">help - enter your name</span>  
					  </div>
					</div>
					
					<!-- Text input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="dateofbirth">Date of Birth</label>  
					  <div class="col-md-4">
					  <input id="dateofbirth" name="dateofbirth" value="{{ old('dateofbirth') }}" type="text" placeholder="12/12/2020" class="form-control input-md">
					  <span class="help-block">hint enter your date of birth</span>  
					  </div>
					</div>
					
					<!-- Text input-->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="weight">Weight</label>  
					  <div class="col-md-4">
					  <input id="weight" name="weight" value="{{ old('weight') }}" type="text" placeholder="0.00" class="form-control input-md">
					  <span class="help-block">help</span>  
					  </div>
					</div>
					
					<!-- Multiple Radios -->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="gender">Gender</label>
					  <div class="col-md-4">
					  <div class="radio">
						<label for="gender-0">
						  <input type="radio" name="gender" id="gender-0" value="1" checked="checked">
						  Male
						</label>
						</div>
					  <div class="radio">
						<label for="gender-1">
						  <input type="radio" name="gender" id="gender-1" value="2">
						  Female
						</label>
						</div>
					  </div>
					</div>
					
					<!-- Select Basic -->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="region">Region</label>
					  <div class="col-md-4">
						<select id="region" name="region" class="form-control">
						  <option value="1">GAR</option>
						  <option value="2">VR</option>
						  <option value="3">UE</option>
						  <option value="4">AR</option>
						</select>
					  </div>
					</div>
					
					<!-- File Button --> 
					<div class="form-group">
					  <label class="col-md-4 control-label" for="filebutton">File Button</label>
					  <div class="col-md-4">
						<input id="filebutton" name="filebutton" class="input-file" type="file">
					  </div>
					</div>
					
					<!-- Button (Double) -->
					<div class="form-group">
					  <label class="col-md-4 control-label" for="submit">save--</label>
					  <div class="col-md-8">
						<button id="submit" name="submit" class="btn btn-success">Save</button>
						<button id="Reset" name="Reset" class="btn btn-default">Reset</button>
						<a class="btn btn-warning" href="{{ route('sampletable.index') }}" role="button">Back</a>
					  </div>
					</div>
					
					</fieldset>
					</form>

                


    </div>
</div>
@endsection
