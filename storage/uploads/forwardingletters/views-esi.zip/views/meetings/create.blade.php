@extends('layouts.app')

@section('content')
	<form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>Meeting Setup</legend>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput"></label>  
  <div class="col-md-4">
  <input id="textinput" name="textinput" type="text" placeholder="Proposed Date" class="form-control input-md" required="">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput"></label>  
  <div class="col-md-4">
  <input id="textinput" name="textinput" type="text" placeholder="Meeting No." class="form-control input-md" required="">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput"></label>  
  <div class="col-md-4">
  <input id="textinput" name="textinput" type="text" placeholder="Meeting Title" class="form-control input-md" required="">
    
  </div>
</div>

<!-- Button Drop Down -->
<div class="form-group">
  <label class="col-md-4 control-label" for="buttondropdown"></label>
  <div class="col-md-4">
    <div class="input-group">
      <input id="buttondropdown" name="buttondropdown" class="form-control" placeholder="Venue" type="text">
      <div class="input-group-btn">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
          Select Venue
          <span class="caret"></span>
        </button>
        <ul class="dropdown-menu pull-right">
          <li><a href="#">Option one</a></li>
          <li><a href="#">Option two</a></li>
          <li><a href="#">Option three</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>

<!-- Button Drop Down -->
<div class="form-group">
  <label class="col-md-4 control-label" for="buttondropdown"></label>
  <div class="col-md-4">
    <div class="input-group">
      <input id="buttondropdown" name="buttondropdown" class="form-control" placeholder="Meeting Type" type="text" required="">
      <div class="input-group-btn">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
          Select Type
          <span class="caret"></span>
        </button>
        <ul class="dropdown-menu pull-right">
          <li><a href="#">Option one</a></li>
          <li><a href="#">Option two</a></li>
          <li><a href="#">Option three</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>

<!--the control buttons for adding agenda and a participant-->
<div class="btn-inline ">

	<a href="{{ url('agendaitem') }}" class="btn btn-primary btn-primary" style=" ">Add Agenda Item</a>

	<a href="{{ url('meetingparticipant') }}" class="btn btn-primary btn-primary">Add Participants</a>

</div>

<!--agenda table-->
<table class="table table-striped table-bordered">
					<tr>
						<th>Item</th><th>Agenda Items</th><th>Delete</th><th>Order</th>
					</tr>
					
					<tr>
						<td>1</td>
						<td>Agenda Title 1</td>
						<td><a href="#" class="btn btn-primary btn-primary"><span class="glyphicon glyphicon-remove"></span> </a></td>
						<td>
						<a href="#" class="btn btn-primary btn-primary"><span class="glyphicon glyphicon-chevron-up"></span> </a>
						</td>
					</tr>
	
</table>
				  
<!--participant table-->

<table class="table table-striped table-bordered">
					<tr>
						<th>Meeting Participants</th><th>Delete</th>
					</tr>
					
					<tr>
						<td>Name of Participant</td>
						<td><a href="#" class="btn btn-primary btn-primary"><span class="glyphicon glyphicon-remove"></span> </a></td>
					</tr>
	
</table>

<!--upload agenda-->
<div class="form-group">
  <label class="col-md-4 control-label" for="filebutton">Upload Agenda</label>
  <div class="col-md-4">
    <input id="filebutton" name="filebutton" class="input-file" type="file">
  </div>
</div>
<!--options to save the -->
<div class="btn-inline " style="padding-right:20px top 20px">

	<a href="#" class="btn btn-primary btn-success">Save as Draft</a>
	<a href="#" class="btn btn-primary btn-primary">Send Invitations</a>
	<a href="#" class="btn btn-primary btn-primary">Cancel</a>
</div>

</fieldset>
</form>




@endsection