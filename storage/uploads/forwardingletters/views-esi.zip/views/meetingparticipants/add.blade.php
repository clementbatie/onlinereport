@extends('layouts.app')

@section('content')

<!--select attendees-->

<div class="row">
    <div class="col-sm-5">
    
<table id="participantTable"
       data-toggle="table"
       data-height="300"
       data-show-refresh="true"
       data-show-toggle="true"
       data-show-columns="true"
       data-toolbar="#toolbar"
       class="table table-fixedheader table-bordered table-striped table-scrollable">
    <thead>
    <tr>
        <th data-field="name">Possible Attendees</th>
    </tr>
    </thead>
    
     <tbody 
                <tr>
                    <td >aaaaaaaaaaa</td>
                </tr>
                <tr>
                   
                    <td >eeeeeeeeeee</td>
                </tr>
                <tr>
                    
                    <td >eeeeeeeeeee</td>
                </tr>
            </tbody>
</table>

    </div>
    
    <!--control buttons for selection-->
    
    <div class="col-sm-2">
        <div>
            <a href="#" class="btn btn-primary btn-primary"><span class="glyphicon glyphicon-chevron-right"></span> </a>
        </div>
        
        <div>
        <a href="#" class="btn btn-primary"><span class="glyphicon glyphicon-chevron-right glyphicon-chevron-right"></span></a>
        </div>
        
        <div>
        <a href="#" class="btn btn-primary"><span class="glyphicon glyphicon-chevron-left"></span> </a>
        </div>
        
        <div>
        <a href="#" class="btn btn-primary"><span class="glyphicon glyphicon-chevron-left glyphicon-chevron-left"></span> </a>
        </div>
        
    
    </div>
    
    <!--selected attendees table-->
    
    <div class="col-sm-5">
    
         
    
<table id="selectedParticipantTable"
       data-toggle="table"
       data-height="300"
       data-show-refresh="true"
       data-show-toggle="true"
       data-show-columns="true"
       data-toolbar="#toolbar"
       class="table table-fixedheader table-bordered table-striped table-scrollable">
    <thead>
    <tr>
        <th data-field="name">Selected Attendess</th>
    </tr>
    </thead>
     <tbody styl
                <tr>
                    <td >aaaaaaaaaaa</td>
                </tr>
                <tr>
                   
                    <td >eeeeeeeeeee</td>
                </tr>
                <tr>
                    
                    <td >eeeeeeeeeee</td>
                </tr>
            </tbody>
</table>
  
    
</div>
</div>
    <!--the control buttons for adding agenda and a participant-->
<div class="btn-inline ">

	<a href="" class="btn btn-primary btn-primary" style=" ">Save</a>

	<a href="{{url('meeting') }}" class="btn btn-primary btn-primary">Cancel</a>

</div>

@endsection