@extends('layouts.app')

@section('content')
<div class="container spark-screen">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-info">
                <div class="panel-heading">Inbox</div>

                <div class="panel-body">
                  <table class="table table-striped">
					<tr>
						<th>Document Titile</th><th>Date Sent</th><th>Sent From</th><th>Receive</th>
					</tr>
					<tr>
						<td><a href="#">{{ $inbox->title or "Default" }}</a>   </td>						
						<td>{{ $inbox->dateSent or "2020-12-21" }}  </td>
						<td>{{ $inbox->from or "Default" }}  </td>
						<td><a href="#" class="btn btn-info btn-block" role="button">Recieve</a>  </td>
					</tr>
				  </table>	  
                </div>
            </div>
        
        
                  <!--  second panel  -->        
         <div class="panel panel-primary">
                <div class="panel-heading">Working Drafts</div>
                <div class="panel-body">                
                  <table class="table table-striped">
					<tr>
						<th>Document Titile</th><th>Date Received</th><th> From</th><th></th>
					</tr>
					<tr>
						<td><a href="#">{{ $drafts->title or "Default" }}</a>   </td>
						<td>{{ $drafts->dateSent or "2020-12-21" }}  </td>
						<td>{{ $drafts->from or "Default" }}  </td>
						<td><a href="#" class="btn btn-primary btn-block" role="button">View</a>  </td>
					</tr>
				  </table>                
            	</div>
		</div>
        
        
        
        </div>
    </div>
</div>
@endsection
