@extends('layouts.app')

@section('content')
<div class="container spark-screen">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Inbox</div>

                <div class="panel-body">
                
                

                <h3>Working drafts</h3>
                  <table class="table table-striped">
					<tr>
						<th>Document Titile</th><th>Date Received</th><th>Received From</th><th></th>
					</tr>
					<tr>
						<td><a href="#">{{ $drafts->title or "Default" }}</a>   </td>
						<td>{{ $drafts->dateSent or "2020-12-21" }}  </td>
						<td>{{ $drafts->from or "Default" }}  </td>
						<td><a href="#" class="btn btn-primary" role="button">View</a>  </td>
					</tr>
				  </table>

                <h3>Sent</h3>
                  <table class="table table-striped">
					<tr>
						<th>Document Titile</th><th>Date Sent</th><th>Sent To</th><th>View</th>
					</tr>
					<tr>
						<td><a href="#">{{ $outbox->title or "Default" }}</a>   </td>						
						<td>{{ $outbox->dateSent or "2020-12-21" }}  </td>
						<td>{{ $outbox->from or "Default" }}  </td>
						<td><a href="#" class="btn btn-info" role="button">View</a>  </td>
					</tr>
				  </table>

				  
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
