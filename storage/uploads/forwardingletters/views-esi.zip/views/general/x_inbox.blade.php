@extends('layouts.app')

@section('content')
<div class="container spark-screen">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                
                
                <h3>Incoming Tray></h3>
                  <table class="table table-striped">
					<tr>
						<th>Document Titile</th><th>Date Sent</th><th>Sent From</th>th>Receive</th>
					</tr>
					<tr>
						<td><a href="#"></a>   
						</td>						
						<td>{{ $data->title or "Default" }}  </td>
						<td>{{ $data->dateSent or "2020-12-21" }}  </td>
						<td>{{ $data->from or "Default" }}  </td>
						<td><a href="#" class="btn btn-info" role="button">Recieve</a>  </td>

					</tr>

    				
				  </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
