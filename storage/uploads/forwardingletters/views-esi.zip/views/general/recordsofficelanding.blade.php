@extends('layouts.app')

@section('content')
<div class="container spark-screen">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            
			<div class="row">
				<div class="col-sm-4"><a href="{{  url('/uploaddocuments') }}" class="btn btn-info btn-block" role="button">Upload a Document</a></div>
				<div class="col-sm-4"><a href="{{  url('/meeting') }}" class="btn btn-warning btn-block" role="button">Set Up Meeting</a></div>
				<div class="col-sm-4"><a href="#" class="btn btn-success btn-block" role="button">Search for Document</a></div>
			</div>

			<hr>
            
            
            <div class="panel panel-default">
                <div class="panel-heading"> </div>

                <div class="panel-body">
                
                
                
                  <table class="table table-striped">
					<tr>
						<th>Messages In last 30 days</th><th></th>
					</tr>
					<tr>
						<td><a href="{{ $inboxRoute }}">Inbox</a>   
						</td>						
						<td>{{ $data->inbox or -1 }}
						</td>
					</tr>

					<tr>
						<td><a href="#">Working on these..</a>   
						</td>						
						<td>{{ $data->workingOn or -1 }}
						</td>
					</tr>

					<tr>
						<td><a href="{{ $outboxRoute }}">Recently Sent</a>   
						</td>						
						<td>{{ $data->recentlySent or -1 }}
						</td>
					</tr>

    				
				  </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
