@extends('layouts.app')

@section('content')
<div class="container spark-screen">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            
			<div class="row" style="height:100px;">
				<div class="col-md-6"><a href="{{  url('/memo') }}" class="btn btn-info btn-block" role="button">Memo</a></div>
				<div class="col-md-6"><a href="{{  url('/executiveapprovalmemo') }}" class="btn btn-success btn-block" role="button">Executive Approval Memo</a></div>				
			</div>

			<div class="row" style="height:100px;">
				<div class="col-md-6"><a href="{{  url('/forwardingletter') }}" class="btn btn-info btn-block" role="button">Forwarding Letter</a></div>
				<div class="col-md-6"><a href="{{  url('/approvaldecisionletter') }}" class="btn btn-success btn-block" role="button">Exec Approval Decision Letter</a></div>				
			</div>

			<div class="row" style="height:100px;">
				<div class="col-md-6"><a href="{{  url('/decisionletter') }}" class="btn btn-warning btn-block" role="button">Cabinet Decision Letter</a></div>
				<div class="col-md-6"><a href="{{  url('/committeereport') }}" class="btn btn-default btn-block" role="button">Committee Report</a></div>				
			</div>

			<div class="row" style="height:100px;">
				<div class="col-md-6"><a href="{{  url('/agenda') }}" class="btn btn-warning btn-block" role="button">Cabinet Agenda</a></div>
				<div class="col-md-6"><a href="{{  url('/minutes') }}" class="btn btn-default btn-block" role="button">Cabinet Minutes</a></div>				
			</div>


        </div>
    </div>
</div>
@endsection
