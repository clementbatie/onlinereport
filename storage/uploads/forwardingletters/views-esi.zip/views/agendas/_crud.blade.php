<!-- form details -->


       <!-- Form Name -->
    
       <legend>Upload Agenda</legend>

    
       <div class="form-group">
         {!! Form::label('ReferenceNo', 'Reference Number:',array('class'=>'col-sm-2 control-label')) !!}
         <div class="col-sm-6">            
            {!! Form::text('ReferenceNo',null, array('class' => 'form-control',  ( $rwstate=='true' ?  'readonly'  :null )) ) !!}
          </div>            
       </div>

       <div class="form-group">
         {!! Form::label('DocumentTitle', 'Agenda Title:',array('class'=>'col-sm-2 control-label')) !!}
         <div class="col-sm-6">            
            {!! Form::text('DocumentTitle',null, array('class' => 'form-control',  ( $rwstate=='true' ?  'readonly'  :null )) ) !!}
          </div>            
       </div>


       <div class="form-group">
          {!! Form::label('DocumentDate', 'Date on Agenda:',array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
            {!! Form::text('DocumentDate', null, array('id' => 'datepicker', 'class' => 'form-control',  ( $rwstate=='true' ?  'readonly'  :null ))) !!}

          </div>
        </div>  

       <div class="form-group">
         {!! Form::label('MeetingID', 'Meeting' ,array('class'=>'col-sm-2 control-label')) !!}
         <div class="col-sm-6">
            {!! Form::select('MeetingID', $meeting, null, ['class' => 'form-control', 'placeholder'=>'Select a Meeting', ( $rwstate=='true' ?  'disabled'  :null )]) !!}
          </div>
       </div>       
        
       
                  
         <div class="form-group">
          {!! Form::label('ProposedMeetingDate', 'Proposed Meeting Date:',array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
            {!! Form::text('ProposedMeetingDate', null, array('id' => 'datepicker', 'class' => 'form-control',  ( $rwstate=='true' ?  'readonly'  :null ))) !!}
          </div>
        </div> 
             
        
         <div class="form-group">
           {!! Form::label('MinistryID', 'Submitting Ministry',array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
            {!! Form::select('MinistryID', $ministry, null, ['class' => 'form-control', 'placeholder'=>'Select a Ministry', ( $rwstate=='true' ?  'disabled'  :null )]) !!}
           </div>
         </div>       
         
         <div class="form-group">
          {!! Form::label('FilePath', 'Upload', array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
            {!! Form::file('FilePath') !!}
          </div>
         </div>
         <div class="form-group">
          
         </div>
         

