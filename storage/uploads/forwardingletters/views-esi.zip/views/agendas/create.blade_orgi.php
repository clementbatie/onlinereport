@extends('layouts.app')

@section('content')
<div class="container spark-screen">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">

 		@include('errors.messages')
    @if ($errors->any())
    <ul>
        {!! implode('', $errors->all('<li class="error">:message</li>')) !!}
    </ul>
    @endif
    {!! Form::open(array('route' => 'agenda.store', 'class'=>'form-horizontal', 'role'=>'form', 'files'=>'true')) !!}
    
       {{ csrf_field() }}

       <fieldset>

    
       <legend>Upload Agenda</legend>

    
       <div class="form-group">
         {!! Form::label('ReferenceNo', 'Reference Number:',array('class'=>'col-sm-2 control-label')) !!}
         <div class="col-sm-6">            
            {!! Form::text('ReferenceNo',null, array('class' => 'form-control') ) !!}
          </div>            
       </div>

       <div class="form-group">
         {!! Form::label('DocumentTitle', 'Agenda Title:',array('class'=>'col-sm-2 control-label')) !!}
         <div class="col-sm-6">            
            {!! Form::text('DocumentTitle',null, array('class' => 'form-control') ) !!}
          </div>            
       </div>


       <div class="form-group">
          {!! Form::label('DocumentDate', 'Date on Agenda:',array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
            {!! Form::text('DocumentDate', null, array('id' => 'datepicker', 'class' => 'form-control')) !!}

          </div>
        </div>  

       <div class="form-group">
         {!! Form::label('MeetingID', 'Meeting' ,array('class'=>'col-sm-2 control-label')) !!}
         <div class="col-sm-6">
            {!! Form::select('MeetingID', $meeting, null, ['class' => 'form-control', 'placeholder'=>'Select a Meeting']) !!}
          </div>
       </div>       
        
       
                  
         <div class="form-group">
          {!! Form::label('ProposedMeetingDate', 'Proposed Meeting Date:',array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
            {!! Form::text('ProposedMeetingDate', null, array('id' => 'datepicker', 'class' => 'form-control')) !!}
          </div>
        </div> 
             
        
         <div class="form-group">
           {!! Form::label('MinistryID', 'Submitting Ministry',array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
            {!! Form::select('MinistryID', $ministry, null, ['class' => 'form-control', 'placeholder'=>'Select a Ministry']) !!}
           </div>
         </div>       
         
         <div class="form-group">
          {!! Form::label('FilePath', 'Upload', array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
            {!! Form::file('FilePath') !!}
          </div>
         </div>
         <div class="form-group">
          
         </div>
         


   

       <!-- Button (Double) -->
       <div class="form-group">
         <label class="col-md-4 control-label" for="save"></label>
         <div class="col-md-8">
           <input type="submit" id="save"  class="btn btn-success">
           <input type="reset" id="reset"  class="btn btn-warning">
           <a class="btn btn-danger" href="{{ url('/agenda') }}" role="button">Cancel</a>
         </div>
         
       </div>

       </fieldset>

    {!! Form::close() !!}
 

    </div>
    </div>
</div>
@endsection
