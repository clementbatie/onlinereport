@extends('layouts.app')

@section('content')

<form class="form-horizontal" action="{{ URL::route('agendaitem.store') }}" method="POST" >
    {{ csrf_field() }}
<fieldset>

<!-- Form Name -->
<legend>Meeting add Agenda item</legend>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput"></label>  
  <div class="col-md-4">
  <input id="textinput" name="AgendaItemId" type="text" placeholder="Agenda item No." class="form-control input-md" >
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput"></label>  
  <div class="col-md-4">
  <input id="textinput" name="Title" type="text" value="{{ old("Title") }}"placeholder="Agenda Item Title" class="form-control input-md" required="">
    
  </div>
</div>

<!-- Button Drop Down -->
<div class="form-group">
  <label class="col-md-4 control-label" for="buttondropdown"></label>
  <div class="col-md-4">
    <div class="input-group">
      <input id="buttondropdown" name="RaisedBy" class="form-control" value="{{ old("RaisedBy") }}" placeholder="Raised By" type="text" required="">
      <div class="input-group-btn">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
          Select Name
          <span class="caret"></span>
        </button>
        <ul class="dropdown-menu pull-right">
          <li><a href="#">Option one</a></li>
          <li><a href="#">Option two</a></li>
          <li><a href="#">Option three</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>

<!-- File Button --> 
<div class="form-group">
  <label class="col-md-4 control-label" for="filebutton">Upload New Memo /File</label>
  <div class="col-md-4">
    <input id="filebutton" name="filebutton" class="input-file" type="file">
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="singlebutton"></label>
  <div class="col-md-4">
    <button id="singlebutton" name="singlebutton" class="btn btn-primary">Attach Existing File</button>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput"></label>  
  <div class="col-md-4">
  <input id="textinput" name="textinput" type="text" placeholder="Keywords" class="form-control input-md" required="">
    
  </div>
</div>

<!-- Textarea -->
<div class="form-group">
  <label class="col-md-4 control-label" for="textarea"></label>
  <div class="col-md-4">                     
    <textarea class="form-control" id="textarea" name="textarea" placeholder="Notes"></textarea>
  </div>
</div>

<!--Attachments table-->
<table class="table table-striped table-bordered">
					<tr>
						<th>Attachments</th><th>Delete</th>
					</tr>
					
					<tr>
						<td>Attachment details</td>
						<td><a href="#" class="btn btn-primary btn-primary"><span class="glyphicon glyphicon-remove"></span> </a></td>
					</tr>
	
</table>
    
    
<div class="btn-inline ">

	<a href="" class="btn btn-primary btn-primary" style=" ">Save</a>

	<a href="{{url('meeting') }}" class="btn btn-danger">Cancel</a>

</div>

</fieldset>
</form>

@endsection