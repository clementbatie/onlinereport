
       <!-- Form Name -->
       <legend>Upload Cabinet Minutes</legend>

       <!-- Text input-->
       <div class="form-group">
         <label class="col-md-4 control-label" for="ReferenceNo">Reference No</label>
         <div class="col-md-5">
         <input id="ReferenceNo" name="ReferenceNo" value="{{ old('ReferenceNo') }}" type="text" placeholder="" class="form-control input-md">

         </div>
       </div>

       <!-- Select Basic -->
       <!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="ActualMeetingDate">Meeting Date</label>
  <div class="col-md-5">
    <input id="ActualMeetingDate" name="ActualMeetingDate" value="{{ old('ActualMeetingDate') }}" type="text" placeholder="" class="form-control input-md" >

  </div>
</div>

<!-- Select Basic -->
<div class="form-group">
<label class="col-md-4 control-label" for="MeetingID">Meeting Number</label>
  <div class="col-md-5">
      <!--  order of params: control_name, data_passed_in, default_value, [customization_settings] -->
    {!! Form::select('MeetingID', $meetingID, null, ['class' => 'form-control', 'placeholder'=>'Select a meeting', ( $rwstate=='true' ?  'disabled'  :null )]) !!}
  </div>
</div>
<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="MeetingTypeID">Meeting Type</label>
  <div class="col-md-5">
  <!--
    <select id="MeetingTypeID" name="MeetingTypeID" class="form-control">
    </select> -->
    {!! Form::select('MeetingTypeID', $meetingTypeID, null, ['class' => 'form-control', 'placeholder'=>'Select a Meeting Type', ( $rwstate=='true' ?  'disabled'  :null )]) !!}
  </div>
</div>
       <!-- File Button -->
       <div class="form-group">
         <label class="col-md-4 control-label" for="FilePath">Upload</label>
         <div class="col-md-4">
              {{ Form::file('FilePath') }}
<!--           <input id="DocumentID" name="DocumentID" value="{{ old('DocumentID') }}" class="input-file" type="file">    -->
         </div>
       </div>

  