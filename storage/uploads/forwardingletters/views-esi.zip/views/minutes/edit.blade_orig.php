@extends('layouts.app')

@section('content')
<div class="container spark-screen">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">

 		@include('errors.messages')

    {{  Form::model($row, array('method' => 'PATCH', 'route' =>array('minutes.update', $row->MinuteID), 'class'=>'form-horizontal', 'role'=>'form', 'files'=>'true'  )) }}
    
       {{ csrf_field() }}

       <fieldset>

       <!-- Form Name -->
       <legend>Upload Cabinet Minutes</legend>

       <!-- Text input-->
       <div class="form-group">
         <label class="col-md-4 control-label" for="ReferenceNo">Reference No</label>
         <div class="col-md-5">
         <input id="ReferenceNo" name="ReferenceNo" value="{{ old('ReferenceNo') }}" type="text" placeholder="" class="form-control input-md">
         </div>
       </div>


       <!-- Select Basic -->
       <!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="ActualMeetingDate">Meeting Date</label>
  <div class="col-md-5">
    <input id="ActualMeetingDate" name="ActualMeetingDate"  type="text" placeholder="" class="form-control input-md" >

    

  </div>
</div>

<!-- Select Basic -->
<div class="form-group">
<label class="col-md-4 control-label" for="MeetingID">Meeting Number</label>
  <div class="col-md-5">
      <!--  order of params: control_name, data_passed_in, default_value, [customization_settings] -->
    {!! Form::select('MeetingID', $meetingID, null, ['class' => 'form-control', 'placeholder'=>'Select a meeting']) !!}
  </div>
</div>
<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="MeetingTypeID">Meeting Type</label>
  <div class="col-md-5">
  <!--
    <select id="MeetingTypeID" name="MeetingTypeID" class="form-control">
    </select> -->
    {!! Form::select('MeetingTypeID', $meetingTypeID, null, ['class' => 'form-control', 'placeholder'=>'Select a Meeting Type']) !!}
  </div>
</div>
       <!-- File Button -->
       <div class="form-group">
         <label class="col-md-4 control-label" for="FilePath">Upload</label>
         <div class="col-md-4">
              {{ Form::file('FilePath') }}
<!--           <input id="DocumentID" name="DocumentID" value="{{ old('DocumentID') }}" class="input-file" type="file">    -->
         </div>
       </div>

       <!-- Button (Double) -->
       <div class="form-group">
         <label class="col-md-4 control-label" for="save"></label>
         <div class="col-md-8">
           <input type="submit" id="save"  class="btn btn-success">
           <input type="reset" id="reset"  class="btn btn-warning">
           <a class="btn btn-danger" href="{{ url('/minutes') }}" role="button">Cancel</a>
         </div>
         
       </div>

       </fieldset>


    {!! Form::close() !!}
 <!--   </form>    --> 
<script>
$('#sandbox-container .input-group.date').datepicker({
    format: "dd/mm/yyyy",
    todayBtn: true,
    clearBtn: true,
    daysOfWeekHighlighted: "0,6",
    todayHighlight: true,
    datesDisabled: ['01/06/2016', '01/21/2016']
});
</script>
    </div>
    </div>
</div>
@endsection
