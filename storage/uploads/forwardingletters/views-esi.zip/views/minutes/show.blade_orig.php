@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">

 		@include('errors.messages')
    <form class="form-horizontal"  method="POST" >
       {{ csrf_field() }}

       <fieldset>

       <!-- Form Name -->
       <legend>Upload Cabinet Minutes</legend>

       <!-- Text input-->
       <div class="form-group">
         <label class="col-md-4 control-label" for="MinutesID">Reference No</label>
         <div class="col-md-5">
         <input id="MinutesID" name="MinutesID" value="{{ old('aname') }}" type="text" placeholder="" class="form-control input-md" required="">

         </div>
       </div>

       <!-- Select Basic -->
       <!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="ActualMeetingDate">Meeting Date</label>
  <div class="col-md-5">
    <select id="ActualMeetingDate" name="ActualMeetingDate" class="form-control">
    </select>
  </div>
</div>

<!-- Select Basic -->
<div class="form-group">
<label class="col-md-4 control-label" for="MeetingID">Meeting Number</label>
<div class="col-md-5">
<select id="MeetingID" name="MeetingID" class="form-control">
</select>
</div>
</div>
<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="MeetingTypeID">Meeting Type</label>
  <div class="col-md-5">
    <select id="MeetingTypeID" name="MeetingTypeID" class="form-control">
    </select>
  </div>
</div>
       <!-- File Button -->
       <div class="form-group">
         <label class="col-md-4 control-label" for="DocumentID">Upload</label>
         <div class="col-md-4">
           <input id="DocumentID" name="DocumentID" value="{{ old('aname') }}" class="input-file" type="file">
         </div>
       </div>

       <!-- Button (Double) -->
       <div class="form-group">
         <label class="col-md-4 control-label" for="save"></label>
         <div class="col-md-8">
           <button id="save" name="save" class="btn btn-success">Save</button>
           <a class="btn btn-danger" href="{{ url('/minutes') }}" role="button">Cancel</a>
         </div>
       </div>

       </fieldset>


</form>

    </div>
    </div>
</div>
@endsection
