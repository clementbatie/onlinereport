@extends('layouts.app')

@section('content')
<div class="container spark-screen">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">

 		@include('errors.messages')
    @if ($errors->any())
    <ul>
        {!! implode('', $errors->all('<li class="error">:message</li>')) !!}
    </ul>
    @endif
    
     {{  Form::model($rows->toArray()+$rows->document->toArray(), array('method' => 'PATCH', 'route' =>array('minute.update', $rows->MinuteID), 'class'=>'form-horizontal', 'role'=>'form', 'files'=>'true'  )) }}
    
         {{ csrf_field() }}

       <fieldset>




       <!-- include the partial    -->
       @include('minutes/_crud', array('rwstate' => 'true') )


        <!-- this is for the path of the previously loaded file  -->
        <!-- eventually replace with link to the actual file  -->
         <div class="form-group">
           {!! Form::label('Path', 'Path', array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
              {!! Form::text('FilePath2',null, array('class' => 'form-control', 'readonly'=>'true', 'placeholder'=>($rows->document->FilePath ? $rows->document->FilePath :null) )) !!}
              </div>
         </div>

         <iframe src="{{ asset('/uploads').$rows->document->FilePath}}" width=100% "style=height:100%" ></iframe>

         <a href="{{ asset('/uploads').$rows->document->FilePath }}">Open the Document!</a> 
            
       <div class="form-group">
         <label class="col-md-4 control-label" for="save"></label>
         <div class="col-md-8">
           
           <a class="btn btn-info" href="{{ action('MinuteController@edit', array($rows->MinuteID)) }}" role="button">Edit</a>
           <a class="btn btn-danger" href="{{ url('/minute') }}" role="button">Cancel</a>
         </div>
         
       </div>

       </fieldset>

    {!! Form::close() !!}
 

    </div>
    </div>
</div>
@endsection
