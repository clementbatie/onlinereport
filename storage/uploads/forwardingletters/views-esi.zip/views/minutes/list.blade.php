@extends('layouts.app')

@section('content')
<div class="container spark-screen">
    <div class="row">


	
		{!! Form::open(array('route' => 'minutes.search')) !!}  
            {!! Form::label('searchString', 'Quick Search:') !!}
            {!! Form::text('searchString') !!}
     	
			{!! Form::submit('Search', array('class' => 'btn btn-info')) !!}
		 
		{!! Form::close() !!}
	

        <div class="col-md-10 col-md-offset-1">
        <h1>Upload Cabinet Minutes</h1>

        @if(Session::has('message'))
		    <p class="alert {{ Session::get('alert-class', 'alert-info') }}">
		        {{Session::get('message')}}
		    </p>
		@endif

	@if ($rows->count())		



		<p><a class="btn btn-info" href="{{ route('minutes.create') }}" role="button">Add new data</a>
		</p>

            <div class="panel panel-default">
                <div class="panel-heading">List of Cabinet Minutes</div>

                <div class="panel-body">

                  <table class="table table-striped">
					<tr>
						<th>Meeting Date</th>
						<th>Meeting Number</th>
						<th>Meeting Type</th>
						<th>Upload</th>
						<th></th>
						<th></th>
						<th></th>
						<th></th>
					</tr>
					@foreach($rows as $row)
					<tr>
						<td>{{$row->ActualMeetingDate or 'DEFAULT'}}</td>
						<td>{{$row->meeting->MeetingNumber or 'DEFAULT'}}</td>
						<td>{{$row->meetingType->MeetingType or 'DEFAULT'}}</td>
						<td>{{$row->document->DocumentTitle or 'DEFAULT'}}</td>					
						<td><a class="btn btn-xs btn-success" href="{{ route('minutes.show', $row->MinutesID)  }}">
                                                   <i class="glyphicon glyphicon-eye-open"></i></a> </td>   
						<td>
                        
                        <a href="{{ action('MinutesController@edit', array($row->MinutesID)) }}"
                            class="btn btn-info btn-xs">
                            <i class="glyphicon glyphicon-pencil"></i></a>

                        </td>

	                    <td>
	                        
	            
	                      {{ Form::open(array('method' 
	                    		=> 'DELETE', 'route' => array('minutes.destroy', $row->MinutesID))) }}  	                  
	                        {{ Form::button('<i class="glyphicon glyphicon-trash"></i>', array('type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick'=>'if(!confirm("Are you sure to delete this item?"))
	                        {
	                        return false;};'    ))  }}
	                        {{ Form::close() }}   
	            
	                    </td>    
					</tr>
					@endforeach

				  </table>

                </div>
            </div>
        </div>
    </div>
    @else
    	There are not records
	@endif

</div>
@endsection
