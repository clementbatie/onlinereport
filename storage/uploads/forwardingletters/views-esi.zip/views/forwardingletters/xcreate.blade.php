@extends('layouts.app')

@section('content')
<div class="container spark-screen">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">

 		@include('errors.messages')

<form class="form-horizontal" action="{{ URL::route('forwardingletter.store') }}" method="POST" class="form-horizontal">
           				 {{ csrf_field() }}
					
<fieldset>

<!-- Form Name -->
<legend>Forwarding Letters Upload</legend>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="referenceNo">Reference No.</label>  
  <div class="col-md-4">
  <input name="referenceNo" class="form-control input-md" id="referenceNo" type="text" placeholder="">
  <span class="help-block"></span>  
  </div>
</div>

<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="selectbasic"></label>
  <div class="col-md-4">
    <select name="selectbasic" class="form-control" id="selectbasic">
      <option value="1">Select Associated Memo</option>
      <option value="2">Option two</option>
    </select>
  </div>
</div>

<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="submittingMinistry"></label>
  <div class="col-md-4">
    <select name="submittingMinistry" class="form-control" id="submittingMinistry">
      <option value="1">Submitting ministry</option>
      <option value="2">Option two</option>
    </select>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="filename"></label>  
  <div class="col-md-4">
  <input name="filename" class="form-control input-md" id="filename" type="text" placeholder="filename">
  <span class="help-block"></span>  
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="singlebutton">Upload</label>
  <div class="col-md-4">
    <button name="singlebutton" class="btn btn-primary" id="singlebutton">Upload</button>
  </div>
</div>

<!-- Button (Double) -->
<div class="form-group">
  <label class="col-md-4 control-label" for="save"></label>
  <div class="col-md-8">
    <button name="save" class="btn btn-success" id="save">Save</button>
    <button name="cancel" class="btn btn-inverse" id="cancel">Cancel</button>
  </div>
</div>

</fieldset>
</form>

    </div>
    </div>
</div>
@endsection