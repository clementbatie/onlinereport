

    
       <legend>Upload Forwarding Letters</legend>

    
       <div class="form-group">
         {!! Form::label('ReferenceNo', 'Reference Number:',array('class'=>'col-sm-2 control-label')) !!}
         <div class="col-sm-6">            
            {!! Form::text('ReferenceNo',null, array('class' => 'form-control', ( $rwstate=='true' ?  'readonly'  :null )) ) !!}
          </div>            
       </div>

       <div class="form-group">
         {!! Form::label('DocumentTitle', 'Letter Title:',array('class'=>'col-sm-2 control-label')) !!}
         <div class="col-sm-6">            
            {!! Form::text('DocumentTitle',null, array('class' => 'form-control', ( $rwstate=='true' ?  'readonly'  :null )) ) !!}
          </div>            
       </div>


       <div class="form-group">
          {!! Form::label('DocumentDate', 'Letter Date:',array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
            {!! Form::text('DocumentDate', null, array('id' => 'datepicker', 'class' => 'form-control', ( $rwstate=='true' ?  'readonly'  :null ))) !!}

          </div>
        </div>  

      


         <div class="form-group">
          {!! Form::label('FilePath', 'Upload', array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
            {!! Form::file('FilePath') !!}
          </div>
         </div>
         <div class="form-group">
          
         </div>
         

