@extends('layouts.app')

@section('content')
<div class="container spark-screen">
    <div class="row">

{!! Form::open(array('route' => 'approvaldecisionletter.search')) !!}  
            {!! Form::label('searchString', 'Quick Search:') !!}
            {!! Form::text('searchString') !!}
     	
			{!! Form::submit('Search', array('class' => 'btn btn-info')) !!}
 
{!! Form::close() !!}
	
	
	

        <div class="col-md-10 col-md-offset-1">
        <h1>Executive Approval Decision Letter</h1>

		<p><a class="btn btn-info" href="{{ route('approvaldecisionletter.create') }}" role="button">Add new data</a>
</p>

            <div class="panel panel-default">
                <div class="panel-heading">Executive Approval Memo</div>

                <div class="panel-body">

                  <table class="table table-striped">
					<tr>
						<th>Reference No</th>
						<th>Document Date</th>
						<th>Ministry</th>
						<th>Title</th>
						<th></th>
						<th></th>
						<th></th>
						<th></th>
					</tr>
					@foreach($rows as $row)
					<tr>
						<td>{{$row->document->ReferenceNo or 'DEFAULT'}}</td>
						<td>{{$row->document->DocumentDate or 'DEFAULT'}}</td>
						<td>{{$row->ministry->Ministry or 'DEFAULT'}}</td>
						<td>{{$row->document->DocumentTitle or 'DEFAULT'}}</td>					
						<td><a class="btn btn-xs btn-success" href="{{ route('approvaldecisionletter.show', $row->ApprovalDecisionLetterID)  }}">
                                                   <i class="glyphicon glyphicon-eye-open"></i></a> </td>   
						<td>
                        
                        <a href="{{ action('ApprovalDecisionLetterController@edit', array($row->ApprovalDecisionLetterID)) }}"
                            class="btn btn-info btn-xs">
                            <i class="glyphicon glyphicon-pencil"></i></a>

                        </td>

	                    <td>
	                        
	            
	                      {{ Form::open(array('method' 
	                    		=> 'DELETE', 'route' => array('approvaldecisionletter.destroy', $row->ApprovalDecisionLetterID))) }}  	                  
	                        {{ Form::button('<i class="glyphicon glyphicon-trash"></i>', array('type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick'=>'if(!confirm("Are you sure to delete this item?"))
	                        {
	                        return false;};'    ))  }}
	                        {{ Form::close() }}   
	            
	                    </td>    
					</tr>
					@endforeach

				  </table>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
