

    
       <legend>Upload Executive Approval Decision Letter</legend>

    
       <div class="form-group">
         {!! Form::label('ReferenceNo', 'Reference Number:',array('class'=>'col-sm-2 control-label')) !!}
         <div class="col-sm-6">            
            {!! Form::text('ReferenceNo',null, array('class' => 'form-control',  ( $rwstate=='true' ?  'readonly'  :null )) ) !!}
          </div>            
       </div>

       <div class="form-group">
         {!! Form::label('DocumentTitle', 'Exec Approval Decision Letter Title:',array('class'=>'col-sm-2 control-label')) !!}
         <div class="col-sm-6">            
            {!! Form::text('DocumentTitle',null, array('class' => 'form-control',  ( $rwstate=='true' ?  'readonly'  :null )) ) !!}
          </div>            
       </div>


        <div class="form-group">
           {!! Form::label('MemoID', 'Associated Memo',array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
            {!! Form::select('MemoID', $memos, null, ['class' => 'form-control', 'placeholder'=>'Select a Memo', ( $rwstate=='true' ?  'disabled'  :null )]) !!}
            </div>
         </div>            
      

      

        <div class="form-group">
           {!! Form::label('ApprovalDecisionLetterID', 'Associated ApprovalDecisionLetter',array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
            {!! Form::select('ApprovalDecisionLetterID', $approvaldecisionletters, null, ['class' => 'form-control', 'placeholder'=>'Select a ApprovalDecisionLetter', 'placeholder'=>'Select a Priority', ( $rwstate=='true' ?  'disabled'  :null )]) !!}
            </div>
         </div>            
      


         <div class="form-group">
           {!! Form::label('MinistryID', 'Submitting Ministry',array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
            {!! Form::select('MinistryID', $ministry, null, ['class' => 'form-control', 'placeholder'=>'Select a Ministry', 'placeholder'=>'Select a Priority', ( $rwstate=='true' ?  'disabled'  :null )]) !!}
           </div>
         </div>       
         

         <div class="form-group">
           {!! Form::label('DecisionStatusID', 'Decision Status',array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
            {!! Form::select('DecisionStatusID', $decisionStatus, null, ['class' => 'form-control', 'placeholder'=>'Select a Decision Status', 'placeholder'=>'Select a Priority', ( $rwstate=='true' ?  'disabled'  :null )]) !!}
           </div>
         </div> 

         <div class="form-group">
          {!! Form::label('FilePath', 'Upload', array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
            {!! Form::file('FilePath') !!}
          </div>
         </div>
         <div class="form-group">
          
         </div>
         


   

     