@extends('layouts.app')

@section('content')
<div class="container spark-screen">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">

 		@include('errors.messages')
    @if ($errors->any())
    <ul>
        {!! implode('', $errors->all('<li class="error">:message</li>')) !!}
    </ul>
    @endif
    {!! Form::open(array('route' => 'memo.store', 'class'=>'form-horizontal', 'role'=>'form', 'files'=>'true')) !!}
    <!-- <form class="form-horizontal" action="minute"  class="form-horizontal"> -->
       {{ csrf_field() }}

       <fieldset>

       <!-- Form Name -->
       <legend>Upload Cabinet Memos</legend>

       <!-- Text input-->
       <div class="form-group">
         {!! Form::label('ReferenceNo', 'Reference Number:' , array('class'=>'col-sm-2 control-label')) !!}
         <div class="col-sm-6">
            {!! Form::text('ReferenceNo',null, array('class' => 'form-control')) !!}
          </div>
       </div>

       <div class="form-group">
         {!! Form::label('DocumentTitle', 'Memo Title:', array('class'=>'col-sm-2 control-label')) !!}
         <div class="col-sm-6">
            {!! Form::text('DocumentTitle',null, array('class' => 'form-control')) !!}
            </div>
       </div>     

       <div class="form-group">
          {!! Form::label('DocumentDate', 'Memo Date:', array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
          {!! Form::text('DocumentDate', '', array('id' => 'datepicker', 'class' => 'form-control')) !!}
          </div>
        </div>       
             
        <div class="form-group">
          {!! Form::label('MinistryID', 'Submitting Ministry', array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
           {!! Form::select('MinistryID', $ministry, null, ['class' => 'form-control', 'placeholder'=>'Select a Ministry']) !!}
           </div>
         </div>       

        <div class="form-group">
           {!! Form::label('IsSigned', 'Is it Signed?', array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
           {!! Form::checkbox('IsSigned', 'IsSigned', false) !!}
           </div>
         </div>
         <div class="form-group">
           {!! Form::label('HasTitle', 'Is it Titled?', array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
           {!! Form::checkbox('HasTitle', 'HasTitle', false) !!}
           </div>
         </div>

         <div class="form-group">
           {!! Form::label('HasSummary', 'Does it have a Summary?', array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
           {!! Form::checkbox('HasSummary', 'HasSummary', false) !!}
           </div>
         </div>

         <div class="form-group">
           {!! Form::label('PriorityID', 'Priority', array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
           {!! Form::select('PriorityID', $priority, null, ['class' => 'form-control', 'placeholder'=>'Select a Priority']) !!}
           </div>
         </div>  

         <div class="form-group">
           {!! Form::label('SourceID', 'Source', array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
           {!! Form::select('SourceID', $source, null, ['class' => 'form-control', 'placeholder'=>'Select a Source']) !!}
           </div>
         </div>       

         <div class="form-group">
           {!! Form::label('Keywords', 'Keywords', array('class'=>'col-sm-2 control-label')) !!}           
           <div class="col-sm-6">
           {!! Form::textarea('Keywords',null, array('class' => 'form-control')) !!}
           </div>
         </div>       
         <div class="form-group">
          {!! Form::label('FilePath', 'Upload', array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
            {!! Form::file('FilePath') !!}
          </div>
         </div>
     



       <!-- Button (Double) -->
       <div class="form-group">
         <label class="col-md-4 control-label" for="save"></label>
         <div class="col-md-8">
           <input type="submit" id="save"  class="btn btn-success">
           <input type="reset" id="reset"  class="btn btn-warning">
           <a class="btn btn-danger" href="{{ url('/memo') }}" role="button">Cancel</a>
         </div>
         
       </div>

       </fieldset>

    {!! Form::close() !!}
 

    </div>
    </div>
</div>
@endsection
