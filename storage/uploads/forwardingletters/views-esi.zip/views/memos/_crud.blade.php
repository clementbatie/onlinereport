<!-- form details -->


       <!-- Form Name -->
       <legend>Upload Cabinet Memos</legend>

       <!-- Text input-->
       <div class="form-group">
         {!! Form::label('ReferenceNo', 'Reference Number:' , array('class'=>'col-sm-2 control-label'  )) !!}
         <div class="col-sm-6">
            {!! Form::text('ReferenceNo',null, array('class' => 'form-control',  ( $rwstate=='true' ?  'readonly'  :null )  )) !!}
          </div>
       </div>

       <div class="form-group">
         {!! Form::label('DocumentTitle', 'Memo Title:', array('class'=>'col-sm-2 control-label')) !!}
         <div class="col-sm-6">
            {!! Form::text('DocumentTitle',null, array('class' => 'form-control', ( $rwstate=='true' ?  'readonly'  :null ) )) !!}
            </div>
       </div>     

       <div class="form-group">
          {!! Form::label('DocumentDate', 'Memo Date:', array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
          {!! Form::text('DocumentDate', null, array('id' => 'datepicker', 'class' => 'form-control', ( $rwstate=='true' ?  'readonly'  :null ) )) !!}
          </div>
        </div>       
             
        <div class="form-group">
          {!! Form::label('MinistryID', 'Submitting Ministry', array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
           {!! Form::select('MinistryID', $ministry, null, ['class' => 'form-control', 'placeholder'=>'Select a Ministry', ( $rwstate=='true' ?  'disabled'  :null ) ]) !!}
           </div>
         </div>       

        <div class="form-group">
           {!! Form::label('IsSigned', 'Is it Signed?', array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
           {!! Form::checkbox('IsSigned', 'IsSigned') !!}
           </div>
         </div>
         <div class="form-group">
           {!! Form::label('HasTitle', 'Is it Titled?', array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
           {!! Form::checkbox('HasTitle', 'HasTitle') !!}
           </div>
         </div>

         <div class="form-group">
           {!! Form::label('HasSummary', 'Does it have a Summary?', array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
           {!! Form::checkbox('HasSummary', 'HasSummary') !!}
           </div>
         </div>

         <div class="form-group">
           {!! Form::label('PriorityID', 'Priority', array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
           {!! Form::select('PriorityID', $priority, null, ['class' => 'form-control', 'placeholder'=>'Select a Priority', ( $rwstate=='true' ?  'disabled'  :null ) ]) !!}
           </div>
         </div>  

         <div class="form-group">
           {!! Form::label('SourceID', 'Source', array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
           {!! Form::select('SourceID', $source, null, ['class' => 'form-control', 'placeholder'=>'Select a Source', ( $rwstate=='true' ?  'disabled'  :null ) ]) !!}
           </div>
         </div>       

         <div class="form-group">
           {!! Form::label('Keywords', 'Keywords', array('class'=>'col-sm-2 control-label')) !!}           
           <div class="col-sm-6">
           {!! Form::textarea('Keywords',null, array('class' => 'form-control', ( $rwstate=='true' ?  'readonly'  :null ) )) !!}
           </div>
         </div>       
         <div class="form-group">
          {!! Form::label('FilePath', 'Upload', array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
            {!! Form::file('FilePath', array('value'=>'nathan', ( $rwstate=='true' ?  'readonly'  :null ) )) !!}
          </div>
         </div>

          



  

   