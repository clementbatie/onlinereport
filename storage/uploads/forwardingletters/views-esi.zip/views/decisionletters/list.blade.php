@extends('layouts.app')

@section('content')
<div class="container spark-screen">
    <div class="row">

{!! Form::open(array('route' => 'decisionletter.search')) !!}  
            {!! Form::label('searchString', 'Quick Search:') !!}
            {!! Form::text('searchString') !!}
     	
			{!! Form::submit('Search', array('class' => 'btn btn-info')) !!}
 
{!! Form::close() !!}
	
	
	

        <div class="col-md-10 col-md-offset-1">
        <h1>Cabinet Decision Letters</h1>

		<p><a class="btn btn-info" href="{{ route('decisionletter.create') }}" role="button">Add new data</a>
</p>

            <div class="panel panel-default">
                <div class="panel-heading">Decision Letters</div>

                <div class="panel-body">

                  <table class="table table-striped">
					<tr>
						<th>Reference No</th>
						<th>Document Date</th>
						<th>Ministry</th>
						<th>Title</th>
						<th></th>
						<th></th>
						<th></th>
						<th></th>
					</tr>
					@foreach($rows as $row)
					<tr>
						<td>{{$row->document->ReferenceNo or 'DEFAULT'}}</td>
						<td>{{$row->document->DocumentDate or 'DEFAULT'}}</td>
						<td>{{$row->ministry->Ministry or 'DEFAULT'}}</td>
						<td>{{$row->document->DocumentTitle or 'DEFAULT'}}</td>					
						<td><a class="btn btn-xs btn-success" href="{{ route('decisionletter.show', $row->DecisionLetterID)  }}">
                                                   <i class="glyphicon glyphicon-eye-open"></i></a> </td>   
						<td>
                        
                        <a href="{{ action('DecisionLetterController@edit', array($row->DecisionLetterID)) }}"
                            class="btn btn-info btn-xs">
                            <i class="glyphicon glyphicon-pencil"></i></a>

                        </td>

	                    <td>
	                        
	            
	                      {{ Form::open(array('method' 
	                    		=> 'DELETE', 'route' => array('decisionletter.destroy', $row->DecisionLetterID))) }}  	                  
	                        {{ Form::button('<i class="glyphicon glyphicon-trash"></i>', array('type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick'=>'if(!confirm("Are you sure to delete this item?"))
	                        {
	                        return false;};'    ))  }}
	                        {{ Form::close() }}   
	            
	                    </td>    
					</tr>
					@endforeach

				  </table>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
