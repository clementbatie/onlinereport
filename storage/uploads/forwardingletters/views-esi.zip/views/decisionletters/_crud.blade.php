
    
       <legend>Upload Cabinet Decision Letter</legend>

    
       <div class="form-group">
         {!! Form::label('ReferenceNo', 'Reference Number:',array('class'=>'col-sm-2 control-label')) !!}
         <div class="col-sm-6">            
            {!! Form::text('ReferenceNo',null, array('class' => 'form-control',  ( $rwstate=='true' ?  'readonly'  :null )) ) !!}
          </div>            
       </div>

       <div class="form-group">
         {!! Form::label('DocumentTitle', 'Letter Title:',array('class'=>'col-sm-2 control-label')) !!}
         <div class="col-sm-6">            
            {!! Form::text('DocumentTitle',null, array('class' => 'form-control',  ( $rwstate=='true' ?  'readonly'  :null )) ) !!}
          </div>            
       </div>


       <div class="form-group">
          {!! Form::label('DocumentDate', 'Letter Date:',array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
            {!! Form::text('DocumentDate', null, array('id' => 'datepicker', 'class' => 'form-control',  ( $rwstate=='true' ?  'readonly'  :null ))) !!}

          </div>
        </div>  

       <div class="form-group">
         {!! Form::label('MeetingID', 'Meeting' ,array('class'=>'col-sm-2 control-label')) !!}
         <div class="col-sm-6">
            {!! Form::select('MeetingID', $meeting, null, ['class' => 'form-control', 'placeholder'=>'Select a Meeting', ( $rwstate=='true' ?  'disabled'  :null )]) !!}
          </div>
       </div>       
        
       
       <div class="form-group">
           {!! Form::label('MemoID', 'Associated Memo',array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
            {!! Form::select('MemoID', $memos, null, ['class' => 'form-control', 'placeholder'=>'Select a Memo', ( $rwstate=='true' ?  'disabled'  :null )]) !!}
            </div>
         </div>  
       
         <div class="form-group">
          {!! Form::label('MeetingDate', 'Meeting Date:',array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
            {!! Form::text('MeetingDate', null, array('id' => 'datepicker', 'class' => 'form-control',  ( $rwstate=='true' ?  'readonly'  :null ))) !!}
          </div>
        </div> 
             
        <div class="form-group">
          {!! Form::label('DecisionStatusID', 'Decision Status',array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
            {!! Form::select('DecisionStatusID', $decisionStatus, null, ['class' => 'form-control', 'placeholder'=>'Select a Status']) !!}
           </div>
         </div>       
        
        
         <div class="form-group">
           {!! Form::label('MinistryID', 'Submitting Ministry',array('class'=>'col-sm-2 control-label')) !!}
           <div class="col-sm-6">
            {!! Form::select('MinistryID', $ministry, null, ['class' => 'form-control', 'placeholder'=>'Select a Ministry', ( $rwstate=='true' ?  'disabled'  :null )]) !!}
           </div>
         </div>       
         
         <div class="form-group">
          {!! Form::label('FilePath', 'Upload', array('class'=>'col-sm-2 control-label')) !!}
          <div class="col-sm-6">
            {!! Form::file('FilePath') !!}
          </div>
         </div>
         <div class="form-group">
          
         </div>
         